package com.exilant.assesment;

import java.util.PriorityQueue;

public class PriorityQueueExample {
	public static void main(String[] args) {
		// it will store in sorted order bcz it implements comparable
		PriorityQueue<Person> priorityQueue = new PriorityQueue<Person>(new Sorter().new IdSorter());
		Person p1 = new Person(101, "Avnish");
		Person p2 = new Person(107, "Manish");
		Person p3 = new Person(100, "Nishant");
		Person p4 = new Person(109, "Sonu");
		Person p5 = new Person(106, "Akash");

		priorityQueue.offer(p1);
		priorityQueue.offer(p2);
		priorityQueue.offer(p3);
		priorityQueue.offer(p4);
		priorityQueue.offer(p5);

		while (!priorityQueue.isEmpty()) {
			System.out.println(priorityQueue.poll());
		}

	}

}
