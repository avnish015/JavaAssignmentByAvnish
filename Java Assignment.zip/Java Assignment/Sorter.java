package com.exilant.assesment;

import java.util.Comparator;

public class Sorter {
	class IdSorter implements Comparator<Person> {

		@Override
		public int compare(Person o1, Person o2) {
			// TODO Auto-generated method stub
			return o1.getId() - o2.getId();
		}

	}

	class NameSorter implements Comparator<Person> {

		@Override
		public int compare(Person o1, Person o2) {
			// TODO Auto-generated method stub
			return o1.getName().compareTo(o2.getName());
		}

	}

}
