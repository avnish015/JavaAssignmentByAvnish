package com.exilant.assesment;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class Synonym {
	public static void main(String[] args) {
		HashMap<String, String[]> map = new HashMap<String, String[]>();

		map.put("accurate", new String[] { "correct", "exact", "right" });
		map.put("quiet", new String[] { "silent", "noiseless","hushed" });
		map.put("happy", new String[] { "cheerful", "joy","gleeful" });
		map.put("accomplish", new String[] { "fulfill", "attain","achieve","execute" });

		for (int i = 0; i < args.length; i++) {
			System.out.println(args[i]);
			String[] syn = map.get(args[i]);
			for (String s : syn) {
				System.out.println("\t" + s );
			}
		}
	}

}
