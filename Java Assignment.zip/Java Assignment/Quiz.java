package com.exilant.assesment;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Quiz {

	String question;
	String options;
	String answer;

	Quiz[] quiz = new Quiz[5];
	
	char ch;
	int correctCount = 0;
	int count = 0;


	public void quizStart() {
		for (int i = 0; i < 5; i++) {
			quiz[i] = new Quiz();
		}

	}

	public void quizQuestions() {
		try {
			quiz[0].question = "Which is a reserved word in the Java programming language?";
			quiz[1].question = "Which will contain the body of the thread?";
			quiz[2].question = "Which class or interface defines the wait(), notify(),and notifyAll() methods?";
			quiz[3].question = "What is the prototype of the default constructor?";
			quiz[4].question = "Which interface does java.util.Hashtable implement?";

		} catch (ArrayIndexOutOfBoundsException e) {
			e.printStackTrace();
			System.err.println("Error Occur!\n" + e.getMessage());
			System.exit(0);
		}
	}

	public void quizOptions() {
		try {
			quiz[0].options = " A.method \n B.native\n C.subclasses \n D.reference";
			quiz[1].options = " A.run()\n B.start() \n C.stop()\n D.main()";
			quiz[2].options = " A.Object \n B.Thread \n C.Runnable\n D.Class";
			quiz[3].options = " A.Test( ) \n B.Test(void) \n C.public Test( ) \n D.public Test(void)";
			quiz[4].options = " A.Java.util.Map \n B.Java.util.List \n C.Java.util.HashTable \n D.Java.util.Collection";

		} catch (ArrayIndexOutOfBoundsException e) {
			System.err.println("Error Occur!\n" + e.getMessage());
			System.exit(0);
		}
	}

	public void quizAnswers() {
		quiz[0].answer = "B";
		quiz[1].answer = "A";
		quiz[2].answer = "A";
		quiz[3].answer = "C";
		quiz[4].answer = "A";

	}

	public void startQuiz() {
		try {
			Scanner sc = new Scanner(System.in);
			String temp = "";

			for (int i = 0; i < 5; i++) {
				System.out.println("............................................................");
				System.out.println("Question " + (i + 1) + ": " + quiz[i].question + "\n" + quiz[i].options);
				System.out.printf("Enter Your Answer:" + "\n");

				temp = sc.next();
				ch = temp.charAt(0);
				temp = Character.toString(ch);

				if (temp.equalsIgnoreCase(quiz[i].answer)) {
					System.out.println("-----------------------------------------------------------");
					System.out.println("Question " + (i + 1));
					System.out.println("Entered Answer is CORRECT");
					correctCount++;

					System.out.println("-----------------------------------------------------------");

				} else {
					System.out.println("-----------------------------------------------------------");
					System.out.println("Question " + (i + 1));
					System.out.println("Entered Answer is INCORRECT");
					System.out.println("Correct Answer is: " + quiz[i].answer);
					System.out.println("-----------------------------------------------------------");
				}

			}
		}

		catch (ArrayIndexOutOfBoundsException e) {
			System.err.println("Error Occur3c!\n" + e.getMessage());
			System.exit(0);
		} catch (InputMismatchException e) {
			System.err.println("Error Occur1!\n" + e.getMessage());
			System.exit(0);
		}
	}

	public void KbcQuizAssessments() {
		System.out.println("\n");
		System.out.println("********Final Result**********");
		System.out.println("\nYou answered " + quiz.length + " questions \n");
		System.out.println("Correct Answer: " + correctCount);
		System.out.println("Incorrect Answer: " + (quiz.length - correctCount));

	}

	// Main
	public static void main(String[] args) {
		Quiz quiz = new Quiz();
		quiz.quizStart();
		quiz.quizQuestions();
		quiz.quizOptions();
		quiz.quizAnswers();
		quiz.startQuiz();
		quiz.KbcQuizAssessments();
	}
}
